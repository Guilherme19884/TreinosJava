package AlegriaNalina;

import java.util.Scanner;

public class HighSurfing {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		//p1.;
		
		//System.out.println(p1.));
		
		Brinquedo b = new Brinquedo ();
		b.setNome("bola");
		b.setIdadeCrianca(2);
		b.setIdadeRcomendada(3);
		b.validarIdade();
		
		System.out.println(b.validarIdade());
	}

}
