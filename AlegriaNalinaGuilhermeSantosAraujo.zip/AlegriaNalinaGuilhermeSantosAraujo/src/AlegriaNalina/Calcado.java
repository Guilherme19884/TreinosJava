package AlegriaNalina;

public class Calcado extends Presente {
	
	private int tamanhoCalcado;

	public int getTamanhoCalcado() {
		return tamanhoCalcado;
	}

	public void setTamanhoCalcado(int tamanhoCalcado) {
		this.tamanhoCalcado = tamanhoCalcado;
	}
	
	
}	
