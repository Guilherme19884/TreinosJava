package AlegriaNalina;

public class Roupa {
	
	
	private char genero;

	public char getGenero() {
		return genero;
	}

	public void setGenero(char genero) {
		this.genero = genero;
	}
	
	
}
