package LojaBike;

public class Acessorios {
	private String farol;
	private String laterna;
	
	
	public Acessorios(String farol, String laterna) {
		super();
		this.farol = farol;
		this.laterna = laterna;
		
	}

	public String getFarol() {
		return farol;
	}

	public void setFarol(String farol) {
		this.farol = farol;
	}

	public String getLaterna() {
		return laterna;
	}

	public void setLaterna(String laterna) {
		this.laterna = laterna;
	}

	
	
	
}
