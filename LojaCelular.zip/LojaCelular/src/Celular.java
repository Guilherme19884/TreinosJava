
public class Celular {
	public String marca;
	public String modelo;
	public int serie;
	public float valor;
	public boolean carregador;
	public boolean  foneDeOuvido;
	
	public void pegarMarca(String marca) {
		this.marca = marca;
	}
	public String mostrarMarca() {
		return this.marca;
	}
	
	
	public void pegarModelo(String modelo) {
		this.modelo = modelo;
	}
	public String mostrarModelo() {
		return this.modelo;
	}
	
	
	public void pegarSerie(int serie) {
		this.serie = serie;
	}
	public int mostrarSerie() {
		return this.serie;
	}
	
	
	public void pegarCarregador(boolean carregador) {
		this.carregador = carregador;
		
	}
	public boolean mostrarCarregador() {
		return this.carregador;
	}
	
	
	public void pegarFoneDeouvido(boolean foneDeOuvido) {
		this.foneDeOuvido = foneDeOuvido;
	}
	public boolean mostrarFoneDeOuvido() {
		return this.foneDeOuvido;
	}
}
	